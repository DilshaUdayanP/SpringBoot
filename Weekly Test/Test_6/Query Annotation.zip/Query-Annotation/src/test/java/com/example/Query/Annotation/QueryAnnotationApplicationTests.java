package com.example.Query.Annotation;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class QueryAnnotationApplicationTests {

	@Test
	void contextLoads() {
	}

}
