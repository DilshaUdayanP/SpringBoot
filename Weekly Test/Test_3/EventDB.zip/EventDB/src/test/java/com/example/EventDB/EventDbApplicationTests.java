package com.example.EventDB;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EventDbApplicationTests {

	@Test
	void contextLoads() {
	}

}
