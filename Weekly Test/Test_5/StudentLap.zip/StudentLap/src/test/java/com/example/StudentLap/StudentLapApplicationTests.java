package com.example.StudentLap;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class StudentLapApplicationTests {

	@Test
	void contextLoads() {
	}

}
