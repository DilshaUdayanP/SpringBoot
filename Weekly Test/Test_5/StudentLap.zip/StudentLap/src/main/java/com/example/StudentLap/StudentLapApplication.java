package com.example.StudentLap;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class StudentLapApplication {

	public static void main(String[] args) {
		SpringApplication.run(StudentLapApplication.class, args);
	}

}
