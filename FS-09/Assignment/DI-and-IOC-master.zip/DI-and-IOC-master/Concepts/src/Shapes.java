public interface Shapes {
    void getArea();
}
